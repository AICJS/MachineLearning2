library(C50)     # C5.0 (C4.5 후속)
library(caret)
library(pROC)

df=read.csv(customer.csv, stringASfactor=False)

# 1) 문자형 컬럼 공백 제거 후 factor로 변환
char_cols <- sapply(df, is.character)
df[char_cols] <- lapply(df[char_cols], function(x) {
  x <- trimws(x)        # 앞뒤 공백 제거
  x[x == ""] <- NA      # 완전 빈 문자열은 NA로 처리
  factor(x)
})

# 2) factor 레벨을 make.names 로 안전하게 변환
for (v in names(df)) {
  if (is.factor(df[[v]])) {
    lv <- levels(df[[v]])
    lv[lv == ""] <- "missing"
    lv <- make.names(lv)
    levels(df[[v]]) <- lv
  }
} 

# 3) 컬럼 이름도 안전하게
names(df) <- make.names(names(df), unique = TRUE)


# 4) 타겟(종속변수)에 NA 있으면 제거
df <- df[!is.na(df$Segmentation), ]
df$Segmentation <- droplevels(df$Segmentation)

# 5) 모델 및 예측





# 6) 클래스별 ROC 커브
classes <- levels(test_data$Segmentation)
roc_list <- list()

for (cl in classes) {
  response_bin <- factor(test_data$Segmentation == cl,
                         levels = c(FALSE, TRUE),
                         labels = c("other", cl))
  prob_cl <- pred_prob[, cl]
  roc_list[[cl]] <- roc(response_bin, prob_cl, levels = c("other", cl))
}

plot(roc_list[[1]], col = 1, lwd = 2,
     main = "One-vs-Rest ROC Curves (C5.0, 4-class)")
if (length(classes) > 1) {
  for (i in 2:length(classes)) {
    plot(roc_list[[i]], col = i, lwd = 2, add = TRUE)
  }
}
legend("bottomright",
       legend = paste0(classes, " (AUC=", round(sapply(roc_list, auc), 3), ")"),
       col    = seq_along(classes),
       lwd    = 2, cex = 0.8)
